$(document).ready(function() {
    $("button").on("click", (e) => {
        console.log(e.target)
        var t = $(e.target).attr('class').split("-")[2]
        $.post("../php/BDDsupression.php", {
            id: t
        })
    })
});