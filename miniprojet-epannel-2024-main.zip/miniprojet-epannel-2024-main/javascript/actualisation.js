function reloadPage(){
    location.reload(true);
}