DROP DATABASE IF EXISTS bddEPanel;
CREATE DATABASE bddEPanel;

USE bddEPanel;

DROP TABLE IF EXISTS direction;
CREATE TABLE direction
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    message VARCHAR(25),
    inclinaison INT 
);

DROP TABLE IF EXISTS directionActuelle;
CREATE TABLE directionActuelle
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    message VARCHAR(25),
    inclinaison INT 
);

insert into direction(message, inclinaison) VALUES
('test','15'),
('directiontest','90'),
('testencore','230'),
('tttttt', '4444'),
('dfgdgv','223')
;
