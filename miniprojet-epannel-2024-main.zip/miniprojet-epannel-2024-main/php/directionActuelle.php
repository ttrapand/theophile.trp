<?php
    $servername = "localhost";
    $username = "EPanel_Admin";
    $password = "password";
    $dbname = "bddEPanel";

    $connexion = mysqli_connect($servername, $username, $password, $dbname);

    $res = mysqli_query($connexion, "SELECT * FROM direction WHERE id = '".$_POST["id"]."'");
    $row = mysqli_fetch_row($res);
    mysqli_query($connexion, "DROP TABLE IF EXISTS directionActuelle");
    mysqli_query($connexion, "CREATE TABLE directionActuelle (id INT AUTO_INCREMENT PRIMARY KEY,message VARCHAR(25),inclinaison INT )");
    mysqli_query($connexion, "INSERT INTO directionActuelle (message, inclinaison) VALUES ('". $row[1] ."', '". $row[2] ."')");
    mysqli_close($connexion);
?>