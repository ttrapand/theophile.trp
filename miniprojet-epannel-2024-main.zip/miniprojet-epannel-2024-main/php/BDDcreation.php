<?php
if(isset($_POST["submit"])){
    $hostname='localhost';
    $username='EPanel_Admin';
    $password='password';
    $dbname = "bddEPanel";

        $dbh = new PDO("mysql:host=$hostname;dbname=$dbname;charset=utf8", $username, $password);
  
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        mysqli_query($connexion, "CREATE TABLE IF NOT EXISTS direction (id INT AUTO_INCREMENT PRIMARY KEY,message VARCHAR(25),inclinaison INT )");
        $stmt = $dbh->prepare("INSERT INTO direction (id, message,  inclinaison) VALUES (:id, :message, :inclinaison)");
 
        $stmt->bindParam(':message', $_POST["message"]);
        $stmt->bindParam(':inclinaison', $_POST["inclinaison"]);
        $stmt->bindParam(':id', $_POST["id"]);

        $stmt->execute(); 
    
}
?>
