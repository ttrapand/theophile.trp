<?php
$servername = "localhost";
$username = "EPanel_Admin";
$password = "password";
$dbname = "bddEPanel";

$connexion = mysqli_connect($servername, $username, $password, $dbname);
    echo $_POST["id"];
    
    mysqli_query($connexion, "DELETE FROM direction WHERE `id` = ".$_POST["id"]);

mysqli_close($connexion);
?>