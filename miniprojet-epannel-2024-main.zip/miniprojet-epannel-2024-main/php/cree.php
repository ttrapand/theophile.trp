<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Panel</title>
    <!-- Font Awesome -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>
<!-- Google Fonts -->
<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>
<!-- MDB -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.min.css"
  rel="stylesheet"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="shortcut icon" href="#">
  <script src="../javascript/actualisation.js"></script>
  </head>
    <body>
    <?php require_once ("navbar.php");?>
        <header>
         </header>
        <br>
        <center>
        <div class="container">
        <form method="post" action="BDDcreation.php">
            <label for="id">ID</label>
            <input type="text" id="id" name="id" placeholder="Votre ID..">
            <br><br>
            <label for="message">message</label>
            <input type="text" id="message" name="message" placeholder="Votre message..">
            <br><br>
            <label for="inclinaison"> Inclinaison</label>
            <input type="text" id="inclinaison" name="inclinaison" placeholder="Votre Inclinaison..">
            <br><br>
            <input type="submit" name="submit" value="Envoyer">
            </form>
            <h3>Liste Actuelle </h3>   
            <table>
            <tr>
              <th>ID</th>
              <th>Message</th>
              <th>Inclinaison</th>
              <?php require_once ("BDDdirection.php");?>
            </tr>
            </table>
           </div>
           <br><br>
          <button class="btn btn-secondary" onclick="reloadPage();">Reload page</button>   
          <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js">
          </script>
        <footer>
          <?php require_once ("footer.php");?>
        </footer>
    </body>
</html>