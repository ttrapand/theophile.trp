<?php
$servername = "localhost";
$username = "EPanel_Admin";
$password = "password";
$dbname = "bddEPanel";

$connexion = mysqli_connect($servername, $username, $password, $dbname);

$sql = "SELECT * FROM directionActuelle";

$resultat = mysqli_query($connexion, $sql);

while ($row = mysqli_fetch_assoc($resultat)) 
{
    echo "<tr>";
    echo "<td>" . $row["id"] . "</td>";
    echo "<td>" . $row["message"] . "</td>";
    echo "<td>" . $row["inclinaison"] . "</td>";
    echo "</tr>";
}
mysqli_close($connexion);
?>
