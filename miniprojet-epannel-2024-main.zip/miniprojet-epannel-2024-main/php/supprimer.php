<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Panel</title>
        <!-- Font Awesome -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>
<!-- Google Fonts -->
<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>
<!-- MDB -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.min.css"
  rel="stylesheet"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="../javascript/javaScriptRemove.js"></script>
  <script src="../javascript/actualisation.js"></script>
  <link rel="shortcut icon" href="#">
  </head>
    <body>
    <?php require_once ("navbar.php");?>
        <header>
         </header>
         <br>
         <center>
         <h1>Direction supprimable </h1>
            <table>
            <tr>
              <th>ID</th>
              <th>Message</th>
              <th>Inclinaison</th>
              <?php require_once ("BDDdirection.php");?>
            </tr>
          </table>
          <br>
             <td><button class="btn btn-secondary-1">Supprimer Direction 1</button></td>
             <td><button class="btn btn-secondary-2">Supprimer Direction 2</button></td>
             <br>
             <br>
             <td><button class="btn btn-secondary-3">Supprimer Direction 3</button></td>
             <td><button class="btn btn-secondary-4">Supprimer Direction 4</button></td>
             <br>
             <br>
             <td><button class="btn btn-secondary-5">Supprimer Direction 5</button></td>
             <td><button class="btn btn-secondary-6">Supprimer Direction 6</button></td>
             <br>
             <br>
             <td><button class="btn btn-secondary-7">Supprimer Direction 7</button></td>
             <td><button class="btn btn-secondary-8">Supprimer Direction 8</button></td>
            </div>
            <br><br>
          <button class="btn btn-secondary" onclick="reloadPage();">Reload page</button>   
          <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js">
          </script>
        <footer>
          <?php require_once ("footer.php");?>
        </footer>
    </body>
</html>