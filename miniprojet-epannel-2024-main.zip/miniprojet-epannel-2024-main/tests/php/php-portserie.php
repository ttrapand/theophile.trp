<?php
$port = fopen("/dev/ttyUSB0", "w");
if ($port === false) {
    die("Erreur lors de l'ouverture du port série.");
}

$message = "Hello\n";

if (fwrite($port, $message) === false) {
    die("Erreur lors de l'écriture sur le port série.");
}

fclose($port);
echo "Message envoyé";
?>
